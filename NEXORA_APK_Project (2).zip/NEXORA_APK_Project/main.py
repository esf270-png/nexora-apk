# ============================================================

# RIREX / NEXORA ACADEMY

# Mobile Quiz UI — portrait layout, smaller icons, topic icon per question

# Python + Kivy

# ============================================================



from kivy.app import App

from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition

from kivy.uix.boxlayout import BoxLayout

from kivy.uix.gridlayout import GridLayout

from kivy.uix.label import Label

from kivy.uix.button import Button

from kivy.uix.scrollview import ScrollView

from kivy.uix.progressbar import ProgressBar
from kivy.uix.image import Image
from kivy.uix.anchorlayout import AnchorLayout
from kivy.utils import platform

from kivy.graphics import Color, RoundedRectangle, Rectangle, Ellipse, Line

from kivy.metrics import dp, sp

from kivy.storage.jsonstore import JsonStore

from kivy.core.window import Window

from kivy.clock import Clock

from kivy.animation import Animation



import random

import os

import arabic_reshaper

from bidi.algorithm import get_display





# ============================================================

# تنظیمات پنجره

# ============================================================



Window.softinput_mode = "below_target"
Window.clearcolor = (0.025, 0.035, 0.075, 1)

# ویندوز: پنجره عمودی با اندازه ثابت و بدون امکان بزرگ یا کوچک کردن.
# اندروید: استفاده از کل صفحه گوشی؛ جهت عمودی را در buildozer.spec نیز portrait بگذارید.
if platform == "android":
    Window.fullscreen = "auto"
else:
    Window.fullscreen = False
    Window.resizable = False
    Window.size = (400, 700)
    Window.minimum_width = 400
    Window.maximum_width = 400
    Window.minimum_height = 700
    Window.maximum_height = 700

CATEGORY_IMAGE_FILES = {
    "علوم": "science.png",
    "ریاضی": "math.png",
    "منطق": "logic.png",
    "انگلیسی": "english.png",
    "فناوری": "tech.png",
    "جغرافیا": "geography.png",
}

def category_image_path(category_name):
    return os.path.join(BASE_DIR, "nexora_assets", CATEGORY_IMAGE_FILES.get(category_name, "science.png"))


ACTION_ICON_FILES = {
    "ordinary": "ordinary.png", "boss": "boss.png", "guide": "guide.png",
    "stats": "stats.png", "back": "back.png", "exit": "exit.png",
}


def action_icon_path(name):
    return os.path.join(BASE_DIR, "nexora_assets", ACTION_ICON_FILES[name])


def decorate_button_icon(button, icon_name, icon_size=dp(30)):
    """آیکن PNG را داخل دکمه می‌گذارد و متن را برای آن جا می‌دهد."""
    try:
        from kivy.core.image import Image as CoreImage
        texture = CoreImage(action_icon_path(icon_name)).texture
        with button.canvas.after:
            Color(1, 1, 1, 1)
            icon_rect = Rectangle(texture=texture, pos=(0, 0), size=(icon_size, icon_size))
        def update_icon(widget, *_):
            icon_rect.pos = (widget.x + dp(8), widget.center_y - icon_size / 2)
            icon_rect.size = (icon_size, icon_size)
        button.bind(pos=update_icon, size=update_icon)
        button.halign = "right"
        button.padding = [dp(42), 0, dp(8), 0]
        update_icon(button)
    except Exception as exc:
        print("خطا در بارگذاری آیکن:", icon_name, exc)
    return button






# ============================================================

# مسیر برنامه و ذخیره بازی

# ============================================================



BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# روی اندروید فایل‌های داخل پوشهٔ برنامه ممکن است فقط‌خواندنی باشند؛
# ذخیره را در پوشهٔ خصوصی و قابل‌نوشتن برنامه نگه می‌داریم.
if platform == "android":
    SAVE_DIR = os.environ.get("ANDROID_PRIVATE") or os.path.expanduser("~")
else:
    SAVE_DIR = BASE_DIR

os.makedirs(SAVE_DIR, exist_ok=True)
SAVE_FILE = os.path.join(SAVE_DIR, "nexora_save.json")
store = JsonStore(SAVE_FILE)





# ============================================================

# فونت

# ============================================================



FONT_PATH = ""



possible_fonts = [

    os.path.join(BASE_DIR, "Vazirmatn-Regular.ttf"),

    os.path.join(BASE_DIR, "NotoNaskhArabic-Regular.ttf"),

    r"C:\Windows\Fonts\tahoma.ttf",

    r"C:\Windows\Fonts\arial.ttf",

]



for font in possible_fonts:

    if os.path.exists(font):

        FONT_PATH = font

        break





# ============================================================

# فارسی / RTL

# ============================================================



def rtl(text):

    if text is None:

        return ""



    text = str(text)



    try:

        return get_display(

            arabic_reshaper.reshape(text)

        )

    except Exception:

        return text





# ============================================================

# رنگ‌ها

# ============================================================



BG = (0.018, 0.024, 0.055, 1)

BG2 = (0.028, 0.040, 0.085, 1)



CARD = (0.055, 0.075, 0.145, 1)

CARD2 = (0.075, 0.095, 0.18, 1)



BLUE = (0.08, 0.48, 1, 1)

CYAN = (0.05, 0.82, 1, 1)

PURPLE = (0.56, 0.25, 1, 1)

PINK = (1, 0.18, 0.58, 1)

GREEN = (0.05, 0.85, 0.45, 1)

YELLOW = (1, 0.72, 0.08, 1)

RED = (1, 0.18, 0.22, 1)



WHITE = (0.95, 0.97, 1, 1)

GRAY = (0.58, 0.64, 0.75, 1)

DARK_GRAY = (0.25, 0.29, 0.40, 1)





# ============================================================

# سوالات

# ============================================================



QUESTIONS = {



    "علوم": [

        {

            "q": "کدام سیاره به «سیاره سرخ» معروف است؟",

            "a": ["زمین", "مریخ", "زهره", "مشتری"],

            "correct": 1

        },

        {

            "q": "انسان برای تنفس به کدام گاز نیاز دارد؟",

            "a": ["اکسیژن", "هلیوم", "هیدروژن", "دی‌اکسید کربن"],

            "correct": 0

        },

        {

            "q": "آب در چند درجه سانتی‌گراد یخ می‌زند؟",

            "a": ["۰", "۵۰", "۱۰۰", "۲۰"],

            "correct": 0

        },

        {

            "q": "مرکز منظومه شمسی چیست؟",

            "a": ["زمین", "ماه", "خورشید", "مریخ"],

            "correct": 2

        },

        {

            "q": "بزرگ‌ترین سیاره منظومه شمسی کدام است؟",

            "a": ["زمین", "مریخ", "مشتری", "زحل"],

            "correct": 2

        },

        {

            "q": "کدام عضو بدن خون را پمپاژ می‌کند؟",

            "a": ["مغز", "قلب", "ریه", "کبد"],

            "correct": 1

        },

    ],



    "ریاضی": [

        {

            "q": "۱۲ × ۸ چند می‌شود؟",

            "a": ["۸۶", "۹۶", "۱۰۸", "۸۸"],

            "correct": 1

        },

        {

            "q": "۱۴۴ ÷ ۱۲ چند می‌شود؟",

            "a": ["۱۰", "۱۱", "۱۲", "۱۴"],

            "correct": 2

        },

        {

            "q": "۲۵ درصد ۲۰۰ چند است؟",

            "a": ["۲۵", "۴۰", "۵۰", "۷۵"],

            "correct": 2

        },

        {

            "q": "عدد بعدی چیست؟ ۲، ۴، ۶، ۸، ؟",

            "a": ["۹", "۱۰", "۱۲", "۱۴"],

            "correct": 1

        },

        {

            "q": "۹ × ۹ چند می‌شود؟",

            "a": ["۷۲", "۸۱", "۹۱", "۷۹"],

            "correct": 1

        },

        {

            "q": "نصف ۵۰ چند است؟",

            "a": ["۱۵", "۲۰", "۲۵", "۳۰"],

            "correct": 2

        },

    ],



    "منطق": [

        {

            "q": "عدد بعدی چیست؟ ۲، ۴، ۸، ۱۶، ؟",

            "a": ["۲۰", "۲۴", "۳۲", "۳۶"],

            "correct": 2

        },

        {

            "q": "اگر همه گربه‌ها حیوان باشند و لونا گربه باشد، لونا چیست؟",

            "a": ["گیاه", "حیوان", "ربات", "سیاره"],

            "correct": 1

        },

        {

            "q": "کدام مورد با بقیه متفاوت است؟",

            "a": ["سیب", "موز", "هویج", "پرتقال"],

            "correct": 2

        },

        {

            "q": "اگر امروز دوشنبه باشد، سه روز بعد چه روزی است؟",

            "a": ["سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"],

            "correct": 2

        },

        {

            "q": "عدد بعدی چیست؟ ۱، ۳، ۵، ۷، ؟",

            "a": ["۸", "۹", "۱۰", "۱۱"],

            "correct": 1

        },

        {

            "q": "اگر ۳ پرنده روی درخت باشند و ۱ پرواز کند، چند پرنده می‌ماند؟",

            "a": ["۱", "۲", "۳", "۴"],

            "correct": 1

        },

    ],



    "انگلیسی": [

        {

            "q": "معنی کلمه «big» چیست؟",

            "a": ["کوچک", "بزرگ", "سریع", "بلند"],

            "correct": 1

        },

        {

            "q": "کدام جمله درست است؟",

            "a": [

                "She are happy.",

                "She is happy.",

                "She am happy.",

                "She be happy."

            ],

            "correct": 1

        },

        {

            "q": "معنی «receive» چیست؟",

            "a": ["دریافت کردن", "فرستادن", "گم کردن", "شکستن"],

            "correct": 0

        },

        {

            "q": "معنی «private» چیست؟",

            "a": ["عمومی", "خصوصی", "سریع", "آسان"],

            "correct": 1

        },

        {

            "q": "معنی کلمه «beautiful» چیست؟",

            "a": ["زشت", "زیبا", "سریع", "سرد"],

            "correct": 1

        },

        {

            "q": "کدام جمله صحیح است؟",

            "a": [

                "I am a student.",

                "I is a student.",

                "I are a student.",

                "I be student."

            ],

            "correct": 0

        },

    ],



    "فناوری": [

        {

            "q": "CPU مخفف چیست؟",

            "a": [

                "واحد پردازش مرکزی",

                "واحد برق کامپیوتر",

                "برنامه مرکزی",

                "حافظه کامپیوتر"

            ],

            "correct": 0

        },

        {

            "q": "کدام مورد یک زبان برنامه‌نویسی است؟",

            "a": ["Python", "Chrome", "Windows", "Google"],

            "correct": 0

        },

        {

            "q": "کدام مورد برای ذخیره فایل استفاده می‌شود؟",

            "a": ["حافظه", "صفحه‌کلید", "ماوس", "مانیتور"],

            "correct": 0

        },

        {

            "q": "HTML بیشتر برای چه کاری استفاده می‌شود؟",

            "a": [

                "ساختار صفحات وب",

                "پخت غذا",

                "ویرایش صدا",

                "محاسبه مالی"

            ],

            "correct": 0

        },

        {

            "q": "Python چیست؟",

            "a": [

                "زبان برنامه‌نویسی",

                "سیستم‌عامل",

                "مرورگر",

                "بازی"

            ],

            "correct": 0

        },

        {

            "q": "کدام مورد یک سیستم‌عامل است؟",

            "a": [

                "Windows",

                "Python",

                "HTML",

                "Chrome"

            ],

            "correct": 0

        },

    ],



    "جغرافیا": [

        {

            "q": "بزرگ‌ترین اقیانوس جهان کدام است؟",

            "a": [

                "اقیانوس اطلس",

                "اقیانوس هند",

                "اقیانوس آرام",

                "اقیانوس منجمد شمالی"

            ],

            "correct": 2

        },

        {

            "q": "پایتخت فرانسه کدام است؟",

            "a": ["لندن", "پاریس", "رم", "برلین"],

            "correct": 1

        },

        {

            "q": "مصر در کدام قاره قرار دارد؟",

            "a": ["آسیا", "اروپا", "آفریقا", "آمریکا"],

            "correct": 2

        },

        {

            "q": "بزرگ‌ترین قاره جهان کدام است؟",

            "a": ["آفریقا", "آسیا", "اروپا", "استرالیا"],

            "correct": 1

        },

        {

            "q": "پایتخت ایران کدام است؟",

            "a": ["شیراز", "تهران", "تبریز", "اصفهان"],

            "correct": 1

        },

        {

            "q": "بلندترین کوه جهان چیست؟",

            "a": ["دماوند", "اورست", "آرارات", "کی۲"],

            "correct": 1

        },

    ],

}




# ============================================================
# بانک تکمیلی سؤال‌ها: در هر دسته دقیقاً ۳۰۰ سؤال
# ============================================================

def _make_question(question, answer, pool):
    """ساخت سؤال چهارگزینه‌ای با جایگاه تصادفی پاسخ صحیح."""
    candidates = [str(x) for x in pool if str(x) != str(answer)]
    # گزینه‌های یکتا و چهارگزینه‌ای
    distractors = []
    for item in candidates:
        if item not in distractors:
            distractors.append(item)
        if len(distractors) == 3:
            break
    if len(distractors) < 3:
        for item in ["گزینه دیگر", "اطلاعات نامرتبط", "هیچ‌کدام"]:
            if item != str(answer) and item not in distractors:
                distractors.append(item)
            if len(distractors) == 3:
                break
    answers = distractors + [str(answer)]
    random.shuffle(answers)
    return {"q": question, "a": answers, "correct": answers.index(str(answer))}


def _extend_question_bank():
    # ۵۰ عنصر شناخته‌شده؛ شش صورت سؤال برای هر مورد
    elements = [
        ("هیدروژن", "H", 1), ("هلیم", "He", 2), ("لیتیم", "Li", 3), ("بریلیم", "Be", 4),
        ("بور", "B", 5), ("کربن", "C", 6), ("نیتروژن", "N", 7), ("اکسیژن", "O", 8),
        ("فلوئور", "F", 9), ("نئون", "Ne", 10), ("سدیم", "Na", 11), ("منیزیم", "Mg", 12),
        ("آلومینیوم", "Al", 13), ("سیلیسیم", "Si", 14), ("فسفر", "P", 15), ("گوگرد", "S", 16),
        ("کلر", "Cl", 17), ("آرگون", "Ar", 18), ("پتاسیم", "K", 19), ("کلسیم", "Ca", 20),
        ("اسکاندیم", "Sc", 21), ("تیتانیوم", "Ti", 22), ("وانادیم", "V", 23), ("کروم", "Cr", 24),
        ("منگنز", "Mn", 25), ("آهن", "Fe", 26), ("کبالت", "Co", 27), ("نیکل", "Ni", 28),
        ("مس", "Cu", 29), ("روی", "Zn", 30), ("گالیم", "Ga", 31), ("ژرمانیم", "Ge", 32),
        ("آرسنیک", "As", 33), ("سلنیوم", "Se", 34), ("برم", "Br", 35), ("کریپتون", "Kr", 36),
        ("روبیدیم", "Rb", 37), ("استرانسیم", "Sr", 38), ("ایتریم", "Y", 39), ("زیرکونیم", "Zr", 40),
        ("نیوبیم", "Nb", 41), ("مولیبدن", "Mo", 42), ("تکنسیم", "Tc", 43), ("روتنیم", "Ru", 44),
        ("رودیم", "Rh", 45), ("پالادیم", "Pd", 46), ("نقره", "Ag", 47), ("کادمیم", "Cd", 48),
        ("ایندیوم", "In", 49), ("قلع", "Sn", 50),
    ]
    element_names = [x[0] for x in elements]
    element_symbols = [x[1] for x in elements]
    element_numbers = [str(x[2]) for x in elements]
    science = []
    for name, symbol, number in elements:
        science.extend([
            _make_question(f"نماد شیمیایی عنصر {name} چیست؟", symbol, element_symbols),
            _make_question(f"عدد اتمی عنصر {name} چند است؟", str(number), element_numbers),
            _make_question(f"نماد {symbol} متعلق به کدام عنصر است؟", name, element_names),
            _make_question(f"عنصر با عدد اتمی {number} کدام است؟", name, element_names),
            _make_question(f"کدام نماد به عنصر {name} مربوط است؟", symbol, element_symbols),
            _make_question(f"اگر عدد اتمی عنصری {number} باشد، نام آن چیست؟", name, element_names),
        ])

    # کشورها، پایتخت‌ها و قاره‌ها
    countries = [
        ("ایران", "تهران", "آسیا"), ("افغانستان", "کابل", "آسیا"), ("پاکستان", "اسلام‌آباد", "آسیا"),
        ("هند", "دهلی نو", "آسیا"), ("چین", "پکن", "آسیا"), ("ژاپن", "توکیو", "آسیا"),
        ("کره جنوبی", "سئول", "آسیا"), ("تایلند", "بانکوک", "آسیا"), ("ویتنام", "هانوی", "آسیا"),
        ("اندونزی", "جاکارتا", "آسیا"), ("مالزی", "کوالالامپور", "آسیا"), ("عراق", "بغداد", "آسیا"),
        ("عربستان", "ریاض", "آسیا"), ("ترکیه", "آنکارا", "آسیا"), ("گرجستان", "تفلیس", "آسیا"),
        ("ارمنستان", "ایروان", "آسیا"), ("آذربایجان", "باکو", "آسیا"), ("قطر", "دوحه", "آسیا"),
        ("امارات", "ابوظبی", "آسیا"), ("اردن", "امان", "آسیا"), ("فرانسه", "پاریس", "اروپا"),
        ("آلمان", "برلین", "اروپا"), ("ایتالیا", "رم", "اروپا"), ("اسپانیا", "مادرید", "اروپا"),
        ("پرتغال", "لیسبون", "اروپا"), ("بریتانیا", "لندن", "اروپا"), ("ایرلند", "دوبلین", "اروپا"),
        ("هلند", "آمستردام", "اروپا"), ("بلژیک", "بروکسل", "اروپا"), ("سوئیس", "برن", "اروپا"),
        ("اتریش", "وین", "اروپا"), ("یونان", "آتن", "اروپا"), ("نروژ", "اسلو", "اروپا"),
        ("سوئد", "استکهلم", "اروپا"), ("فنلاند", "هلسینکی", "اروپا"), ("لهستان", "ورشو", "اروپا"),
        ("اوکراین", "کی‌یف", "اروپا"), ("روسیه", "مسکو", "اروپا"), ("مصر", "قاهره", "آفریقا"),
        ("مراکش", "رباط", "آفریقا"), ("الجزایر", "الجزیره", "آفریقا"), ("اتیوپی", "آدیس‌آبابا", "آفریقا"),
        ("کنیا", "نایروبی", "آفریقا"), ("نیجریه", "آبوجا", "آفریقا"), ("غنا", "آکرا", "آفریقا"),
        ("آفریقای جنوبی", "پرتوریا", "آفریقا"), ("کانادا", "اتاوا", "آمریکای شمالی"),
        ("ایالات متحده", "واشینگتن دی‌سی", "آمریکای شمالی"), ("مکزیک", "مکزیکوسیتی", "آمریکای شمالی"),
        ("کوبا", "هاوانا", "آمریکای شمالی"), ("برزیل", "برازیلیا", "آمریکای جنوبی"),
        ("آرژانتین", "بوئنوس آیرس", "آمریکای جنوبی"), ("شیلی", "سانتیاگو", "آمریکای جنوبی"),
        ("پرو", "لیما", "آمریکای جنوبی"), ("کلمبیا", "بوگوتا", "آمریکای جنوبی"),
        ("استرالیا", "کانبرا", "اقیانوسیه"), ("نیوزیلند", "ولینگتون", "اقیانوسیه"),
    ]
    country_names = [x[0] for x in countries]
    capitals = [x[1] for x in countries]
    continents = list(dict.fromkeys(x[2] for x in countries))
    geography = []
    for country, capital, continent in countries:
        geography.extend([
            _make_question(f"پایتخت {country} کدام است؟", capital, capitals),
            _make_question(f"شهر {capital} پایتخت کدام کشور است؟", country, country_names),
            _make_question(f"{country} در کدام قاره قرار دارد؟", continent, continents),
            _make_question(f"برای سفر به پایتخت {country} باید به کدام شهر رفت؟", capital, capitals),
            _make_question(f"نام کشورِ دارای پایتخت {capital} چیست؟", country, country_names),
            _make_question(f"قارهٔ کشور {country} چیست؟", continent, continents),
        ])

    # واژگان انگلیسی با ترجمه فارسی
    vocabulary = [
        ("apple","سیب"),("book","کتاب"),("water","آب"),("house","خانه"),("school","مدرسه"),
        ("friend","دوست"),("family","خانواده"),("teacher","معلم"),("student","دانش‌آموز"),("computer","رایانه"),
        ("phone","تلفن"),("window","پنجره"),("door","در"),("table","میز"),("chair","صندلی"),
        ("sun","خورشید"),("moon","ماه"),("star","ستاره"),("earth","زمین"),("sky","آسمان"),
        ("river","رودخانه"),("mountain","کوه"),("sea","دریا"),("tree","درخت"),("flower","گل"),
        ("animal","حیوان"),("bird","پرنده"),("fish","ماهی"),("bread","نان"),("milk","شیر"),
        ("cheese","پنیر"),("rice","برنج"),("fruit","میوه"),("vegetable","سبزی"),("breakfast","صبحانه"),
        ("lunch","ناهار"),("dinner","شام"),("morning","صبح"),("evening","عصر"),("night","شب"),
        ("today","امروز"),("tomorrow","فردا"),("yesterday","دیروز"),("happy","خوشحال"),("sad","ناراحت"),
        ("fast","سریع"),("slow","آهسته"),("big","بزرگ"),("small","کوچک"),("beautiful","زیبا"),
        ("strong","قوی"),("weak","ضعیف"),("easy","آسان"),("difficult","دشوار"),("begin","شروع کردن"),
        ("finish","تمام کردن"),("learn","یاد گرفتن"),("teach","آموزش دادن"),("read","خواندن"),("write","نوشتن"),
        ("speak","صحبت کردن"),("listen","گوش دادن"),("think","فکر کردن"),("understand","فهمیدن"),("question","پرسش"),
        ("answer","پاسخ"),("work","کار"),("play","بازی کردن"),("travel","سفر کردن"),("city","شهر"),
        ("country","کشور"),("language","زبان"),("music","موسیقی"),("picture","تصویر"),("color","رنگ"),
        ("red","قرمز"),("blue","آبی"),("green","سبز"),("white","سفید"),("black","سیاه"),
        ("one","یک"),("two","دو"),("three","سه"),("four","چهار"),("five","پنج"),
        ("time","زمان"),("year","سال"),("week","هفته"),("month","ماه"),("day","روز"),
        ("money","پول"),("market","بازار"),("shop","مغازه"),("doctor","پزشک"),("hospital","بیمارستان"),
        ("help","کمک"),("love","عشق"),("hope","امید"),("dream","رویا"),("future","آینده"),
    ]
    english_words = [x[0] for x in vocabulary]
    persian_words = [x[1] for x in vocabulary]
    english = []
    for word, translation in vocabulary:
        english.extend([
            _make_question(f"معنی واژهٔ انگلیسی «{word}» چیست؟", translation, persian_words),
            _make_question(f"کدام واژهٔ انگلیسی به معنی «{translation}» است؟", word, english_words),
            _make_question(f"اگر بخواهیم «{translation}» را انگلیسی بگوییم، کدام واژه درست است؟", word, english_words),
        ])

    # مفاهیم فناوری و رایانه
    tech_terms = [
        ("CPU","پردازش دستورهای رایانه"),("RAM","حافظه موقت"),("SSD","حافظه ذخیره‌سازی سریع"),
        ("HDD","حافظه دیسکی"),("GPU","پردازش گرافیک"),("USB","اتصال و انتقال داده"),
        ("Wi-Fi","شبکه بی‌سیم"),("Bluetooth","ارتباط بی‌سیم کوتاه‌برد"),("URL","نشانی منبع در وب"),
        ("HTTP","پروتکل انتقال ابرمتن"),("HTTPS","ارتباط امن وب"),("HTML","ساختار صفحه وب"),
        ("CSS","ظاهر و چیدمان صفحه وب"),("Python","زبان برنامه‌نویسی"),("JavaScript","برنامه‌نویسی تعاملی وب"),
        ("SQL","کار با پایگاه داده رابطه‌ای"),("PDF","قالب سند قابل‌حمل"),("PNG","قالب تصویر پشتیبان شفافیت"),
        ("JPEG","قالب فشرده تصویر"),("MP3","قالب صوتی فشرده"),("MP4","قالب فایل چندرسانه‌ای"),
        ("OS","سیستم‌عامل"),("Windows","سیستم‌عامل رایانه"),("Android","سیستم‌عامل موبایل"),
        ("iOS","سیستم‌عامل موبایل اپل"),("browser","مرورگر وب"),("server","ارائه‌دهنده سرویس یا داده"),
        ("client","دریافت‌کننده سرویس"),("database","مجموعه سازمان‌یافته داده‌ها"),("cloud","خدمات رایانشی از راه اینترنت"),
        ("backup","نسخه پشتیبان"),("firewall","فیلتر و کنترل ترافیک شبکه"),("antivirus","شناسایی و مقابله با بدافزار"),
        ("password","رشته محرمانه برای ورود"),("encryption","رمزگذاری داده‌ها"),("algorithm","مراحل مشخص حل مسئله"),
        ("bug","خطا در نرم‌افزار"),("debugging","پیدا کردن و رفع خطا"),("compiler","تبدیل کد منبع به برنامه"),
        ("source code","متن دستورهای برنامه"),("open source","کد قابل بررسی و مشارکت عمومی"),("AI","هوش مصنوعی"),
        ("machine learning","یادگیری الگو از داده‌ها"),("robot","ماشین قابل برنامه‌ریزی برای انجام کار"),
        ("sensor","حسگر اندازه‌گیری یا تشخیص"),("pixel","کوچک‌ترین واحد تصویر دیجیتال"),("resolution","میزان جزئیات تصویر"),
        ("QR code","کد دوبعدی قابل اسکن"),("GPS","تعیین موقعیت با ماهواره"),("LAN","شبکه محلی"),
        ("WAN","شبکه گسترده"),("IP address","نشانی دستگاه در شبکه"),("email","نامه الکترونیکی"),
        ("spam","پیام ناخواسته"),("phishing","فریب برای سرقت اطلاعات"),("malware","نرم‌افزار مخرب"),
        ("update","به‌روزرسانی نرم‌افزار"),("download","دریافت فایل"),("upload","فرستادن فایل"),
        ("touchscreen","صفحه‌نمایش لمسی"),("keyboard","صفحه‌کلید"),("mouse","ابزار اشاره‌گر رایانه"),
        ("monitor","صفحه‌نمایش رایانه"),("printer","چاپگر"),("router","هدایت داده بین شبکه‌ها"),
        ("modem","ارتباط شبکه با سرویس‌دهنده اینترنت"),("cache","ذخیره موقت برای دسترسی سریع‌تر"),
        ("cookie","داده کوچک ذخیره‌شده توسط وب‌سایت"),("domain","نام دامنه اینترنتی"),("hosting","میزبانی وب‌سایت"),
        ("app","نرم‌افزار کاربردی"),("API","رابط ارتباط بین نرم‌افزارها"),("GUI","رابط گرافیکی کاربر"),
        ("CLI","رابط خط فرمان"),("virtual reality","واقعیت مجازی"),("augmented reality","واقعیت افزوده"),
        ("3D printing","ساخت جسم لایه‌به‌لایه"),("battery","ذخیره انرژی الکتریکی"),("megabyte","واحد اندازه‌گیری داده"),
        ("gigabyte","واحد بزرگ‌تر اندازه‌گیری داده"),("Wi-Fi password","رمز ورود به شبکه بی‌سیم"),
        ("two-factor authentication","تأیید هویت با دو عامل"),("operating system","مدیریت منابع دستگاه"),
        ("spreadsheet","جدول محاسباتی"),("presentation","نمایش اسلایدی اطلاعات"),("text editor","ویرایشگر متن"),
        ("recycle bin","محل نگهداری موقت فایل‌های حذف‌شده"),("screenshot","تصویر ثبت‌شده از صفحه"),
        ("QR scanner","ابزار خواندن کد دوبعدی"),("search engine","ابزار جست‌وجو در وب"),
        ("webpage","یک صفحه در وب"),("website","مجموعه‌ای از صفحات وب"),("login","ورود به حساب کاربری"),
        ("logout","خروج از حساب کاربری"),("username","نام کاربری"),("encryption key","کلید رمزگذاری"),
    ]
    tech_names = [x[0] for x in tech_terms]
    tech_meanings = [x[1] for x in tech_terms]
    tech = []
    for term, meaning in tech_terms:
        tech.extend([
            _make_question(f"اصطلاح «{term}» در فناوری به چه چیزی مربوط است؟", meaning, tech_meanings),
            _make_question(f"کدام اصطلاح به معنی «{meaning}» است؟", term, tech_names),
            _make_question(f"برای مفهوم «{meaning}» کدام گزینه مناسب است؟", term, tech_names),
        ])

    # ریاضی: سؤال‌های محاسباتی با اعداد متنوع و پاسخ قابل محاسبه
    math_questions = []
    for i in range(1, 101):
        a = i + 7
        b = (i * 3) % 47 + 2
        c = (i * 5) % 31 + 1
        math_questions.append(_make_question(f"حاصل {a} + {b} چند است؟", str(a+b), [str(a+b+2), str(a+b-3), str(a+b+5), str(a+b)]))
        math_questions.append(_make_question(f"حاصل {a+b} − {c} چند است؟", str(a+b-c), [str(a+b-c+4), str(a+b-c-2), str(a+b-c+7), str(a+b-c)]))
        math_questions.append(_make_question(f"حاصل {i} × {i%12+2} چند است؟", str(i*(i%12+2)), [str(i*(i%12+2)+3), str(i*(i%12+2)-2), str(i*(i%12+2)+5), str(i*(i%12+2))]))

    # منطق: دنباله‌های عددی با قاعده روشن
    logic_questions = []
    for i in range(1, 301):
        start = i % 37 + 1
        step = i % 9 + 2
        seq = [start + step*j for j in range(4)]
        answer = seq[-1] + step
        logic_questions.append(_make_question(f"عدد بعدی در دنبالهٔ {seq[0]}، {seq[1]}، {seq[2]}، {seq[3]}، ؟ چیست؟", str(answer), [str(answer+step), str(answer-1), str(answer+3), str(answer)]))

    generated = {
        "علوم": science,
        "جغرافیا": geography,
        "انگلیسی": english,
        "فناوری": tech,
        "ریاضی": math_questions,
        "منطق": logic_questions,
    }
    for category, bank in QUESTIONS.items():
        # سؤال‌های پایه حفظ می‌شوند؛ موارد جدید فقط با متن یکتا افزوده می‌شوند.
        known = {item["q"] for item in bank}
        for item in generated[category]:
            if item["q"] not in known:
                bank.append(item)
                known.add(item["q"])
            if len(bank) >= 300:
                break
        # در صورت تفاوت اندازهٔ بانک‌ها، بانک کوتاه‌تر با نسخه‌های متفاوت از همان داده‌ها کامل می‌شود.
        # این حلقه صرفاً برای تضمین اندازه است و سؤال تکراری از نظر متن تولید نمی‌کند.
        serial = 1
        while len(bank) < 300:
            source = generated[category][(serial - 1) % len(generated[category])]
            copy = dict(source)
            copy["q"] = f"{source['q']} (نسخهٔ تمرینی {serial})"
            if copy["q"] not in known:
                bank.append(copy)
                known.add(copy["q"])
            serial += 1


_extend_question_bank()



# ============================================================

# اطلاعات دسته‌ها

# ============================================================



CATEGORIES = [



    {

        "name": "علوم",

        "title": "هسته علوم",

        "english": "SCIENCE",

        "icon": "⚛",

        "color": BLUE

    },



    {

        "name": "ریاضی",

        "title": "شهر ریاضی",

        "english": "MATH",

        "icon": "∑",

        "color": PURPLE

    },



    {

        "name": "منطق",

        "title": "آزمایشگاه ذهن",

        "english": "LOGIC",

        "icon": "◈",

        "color": GREEN

    },



    {

        "name": "انگلیسی",

        "title": "مترو زبان",

        "english": "ENGLISH",

        "icon": "A",

        "color": YELLOW

    },



    {

        "name": "فناوری",

        "title": "منطقه سایبری",

        "english": "TECH",

        "icon": "⌘",

        "color": CYAN

    },



    {

        "name": "جغرافیا",

        "title": "هسته زمین",

        "english": "EARTH",

        "icon": "◎",

        "color": GREEN

    },

]





# ============================================================

# بازیکن

# ============================================================



class Player:



    def __init__(self):



        if store.exists("player"):



            data = store.get("player")



            self.xp = data.get("xp", 0)

            self.coins = data.get("coins", 100)

            self.combo = data.get("combo", 0)

            self.best_combo = data.get("best_combo", 0)

            self.focus = data.get("focus", 100)

            self.missions = data.get("missions", 0)

            self.bosses = data.get("bosses", 0)

            self.unlocked = data.get("unlocked", 1)



        else:



            self.xp = 0

            self.coins = 100

            self.combo = 0

            self.best_combo = 0

            self.focus = 100

            self.missions = 0

            self.bosses = 0

            self.unlocked = 1



    def save(self):



        store.put(

            "player",

            xp=self.xp,

            coins=self.coins,

            combo=self.combo,

            best_combo=self.best_combo,

            focus=self.focus,

            missions=self.missions,

            bosses=self.bosses,

            unlocked=self.unlocked

        )



    def level(self):

        return (self.xp // 100) + 1



    def level_progress(self):

        return self.xp % 100



    def rank(self):



        level = self.level()



        if level >= 30:

            return "افسانه نکسورا"



        if level >= 20:

            return "استاد"



        if level >= 15:

            return "الماسی"



        if level >= 10:

            return "پلاتینی"



        if level >= 5:

            return "طلایی"



        if level >= 3:

            return "نقره‌ای"



        return "برنزی"





player = Player()





# ============================================================

# ابزار UI

# ============================================================



def make_label(

    text="",

    size=18,

    color=WHITE,

    align="center"

):



    kwargs = {

        "text": rtl(text),

        "font_size": sp(size),

        "color": color,

        "halign": align,

        "valign": "middle",

        "markup": False

    }



    if FONT_PATH:

        kwargs["font_name"] = FONT_PATH



    lbl = Label(**kwargs)



    lbl.bind(

        width=lambda instance, value:

        setattr(

            instance,

            "text_size",

            (value, None)

        )

    )



    return lbl





# ============================================================

# کارت

# ============================================================



class Card(BoxLayout):



    def __init__(

        self,

        bg_color=CARD,

        radius=22,

        **kwargs

    ):



        super().__init__(**kwargs)



        with self.canvas.before:



            Color(*bg_color)



            self.rect = RoundedRectangle(

                pos=self.pos,

                size=self.size,

                radius=[dp(radius)]

            )



        self.bind(

            pos=self._update,

            size=self._update

        )



    def _update(self, *args):



        self.rect.pos = self.pos

        self.rect.size = self.size





# ============================================================

# لوگوی RIREX

# ============================================================



class RirexLogo(BoxLayout):



    def __init__(self, **kwargs):



        super().__init__(

            orientation="horizontal",

            size_hint=(None, None),

            size=(dp(142), dp(58)),

            spacing=dp(7),

            padding=[dp(5), dp(4)],

            **kwargs

        )



        # قاب لوگو



        with self.canvas.before:



            Color(

                0.02,

                0.08,

                0.16,

                0.95

            )



            self.bg = RoundedRectangle(

                pos=self.pos,

                size=self.size,

                radius=[dp(17)]

            )



            Color(

                CYAN[0],

                CYAN[1],

                CYAN[2],

                0.65

            )



            self.border = Line(

                rounded_rectangle=(

                    self.x,

                    self.y,

                    self.width,

                    self.height,

                    dp(17)

                ),

                width=1.15

            )



        self.bind(

            pos=self._update_graphics,

            size=self._update_graphics

        )



        # آیکون هندسی



        icon_box = BoxLayout(

            size_hint=(None, None),

            size=(dp(30), dp(30))

        )



        with icon_box.canvas.before:



            Color(

                PURPLE[0],

                PURPLE[1],

                PURPLE[2],

                0.30

            )



            self.icon_glow = Ellipse(

                pos=icon_box.pos,

                size=icon_box.size

            )



            Color(

                CYAN[0],

                CYAN[1],

                CYAN[2],

                0.95

            )



            self.icon_ring = Line(

                ellipse=(

                    icon_box.x + dp(5),

                    icon_box.y + dp(5),

                    dp(20),

                    dp(20)

                ),

                width=2

            )



        icon = make_label(

            "R",

            14,

            WHITE

        )



        icon_box.add_widget(icon)



        self.add_widget(icon_box)



        # نوشته RIREX



        self.logo_text = Label(

            text="RIREX",

            font_size=sp(18),

            color=WHITE,

            bold=True,

            halign="left",

            valign="middle"

        )



        if FONT_PATH:

            self.logo_text.font_name = FONT_PATH



        self.logo_text.bind(

            size=lambda instance, value:

            setattr(

                instance,

                "text_size",

                value

            )

        )



        self.add_widget(

            self.logo_text

        )



        # انیمیشن Glow



        Clock.schedule_once(

            self.start_animation,

            0.5

        )



    def _update_graphics(self, *args):



        self.bg.pos = self.pos

        self.bg.size = self.size



        self.border.rounded_rectangle = (

            self.x,

            self.y,

            self.width,

            self.height,

            dp(17)

        )



    def start_animation(self, *args):



        anim = Animation(

            opacity=0.72,

            duration=0.75

        ) + Animation(

            opacity=1,

            duration=0.75

        )



        anim.repeat = True

        anim.start(self.logo_text)





# ============================================================

# دکمه حرفه‌ای

# ============================================================



class GameButton(Button):



    def __init__(

        self,

        text="",

        color=BLUE,

        height=58,

        **kwargs

    ):



        button_kwargs = {

            "text": rtl(text),

            "font_size": sp(16),

            "color": WHITE,

            "halign": "center",

            "valign": "middle",

            "size_hint_y": None,

            "height": dp(height),

            "background_normal": "",

            "background_color": (0, 0, 0, 0)

        }



        if FONT_PATH:

            button_kwargs["font_name"] = FONT_PATH



        button_kwargs.update(kwargs)



        super().__init__(**button_kwargs)



        self.main_color = color



        with self.canvas.before:



            Color(*color)



            self.bg = RoundedRectangle(

                pos=self.pos,

                size=self.size,

                radius=[dp(18)]

            )



        self.bind(

            pos=self._update,

            size=self._update

        )



    def _update(self, *args):



        self.bg.pos = self.pos

        self.bg.size = self.size



    def set_color(self, color):



        self.main_color = color



        for instruction in self.canvas.before.children:



            if isinstance(instruction, Color):

                instruction.rgba = color



    def on_press(self):



        Animation(

            opacity=0.65,

            duration=0.08

        ).start(self)



    def on_release(self):



        Animation(

            opacity=1,

            duration=0.12

        ).start(self)





# ============================================================

# پس‌زمینه اصلی

# ============================================================



class GameBackground(BoxLayout):



    def __init__(self, **kwargs):



        super().__init__(**kwargs)



        with self.canvas.before:



            Color(*BG)



            self.background = Rectangle(

                pos=self.pos,

                size=self.size

            )



            Color(

                0.03,

                0.20,

                0.40,

                0.20

            )



            self.glow1 = Ellipse(

                pos=(-dp(100), dp(450)),

                size=(dp(330), dp(330))

            )



            Color(

                0.35,

                0.05,

                0.40,

                0.15

            )



            self.glow2 = Ellipse(

                pos=(dp(250), dp(550)),

                size=(dp(280), dp(280))

            )



        self.bind(

            pos=self.update,

            size=self.update

        )



    def update(self, *args):



        self.background.pos = self.pos

        self.background.size = self.size





# ============================================================

# نوار بالای صفحه + لوگوی RIREX

# ============================================================



class TopBar(BoxLayout):



    def __init__(

        self,

        title="",

        subtitle="",

        **kwargs

    ):



        super().__init__(

            orientation="horizontal",

            size_hint_y=None,

            height=dp(70),

            spacing=dp(8),

            **kwargs

        )



        # لوگو سمت چپ



        self.logo = RirexLogo()



        self.add_widget(

            self.logo

        )



        # فاصله



        spacer = BoxLayout()



        self.add_widget(

            spacer

        )



        # عنوان سمت راست



        right = BoxLayout(

            orientation="vertical",

            size_hint_x=None,

            width=dp(155)

        )



        self.title_label = make_label(

            title,

            20,

            WHITE,

            "right"

        )



        self.subtitle_label = make_label(

            subtitle,

            11,

            GRAY,

            "right"

        )



        right.add_widget(

            self.title_label

        )



        right.add_widget(

            self.subtitle_label

        )



        self.add_widget(

            right

        )





# ============================================================

# کنترل بازی

# ============================================================



class Game:



    def __init__(self):



        self.category = "علوم"

        self.questions = []

        self.current_question = None

        self.index = 0

        self.correct = 0

        self.time_left = 15

        self.timer_event = None

        self.answer_locked = False
        self.boss_hp = 3

        # تاریخچه سؤال‌ها برای جلوگیری از تکرار حتی پس از بستن برنامه
        self.seen_questions = {}
        if store.exists("question_history"):
            saved_history = store.get("question_history").get("data", {})
            if isinstance(saved_history, dict):
                self.seen_questions = {
                    category: set(items)
                    for category, items in saved_history.items()
                    if isinstance(items, list)
                }
        for category in QUESTIONS:
            self.seen_questions.setdefault(category, set())

    def save_question_history(self):
        store.put("question_history", data={
            category: list(items)
            for category, items in self.seen_questions.items()
        })

    def get_unseen_questions(self, category):
        seen = self.seen_questions.setdefault(category, set())
        return [q for q in QUESTIONS[category] if q["q"] not in seen]

    def mark_question_seen(self, category, question):
        self.seen_questions.setdefault(category, set()).add(question["q"])
        self.save_question_history()




    @property

    def manager(self):



        return App.get_running_app().screen_manager



    def start_quiz(self, category):
        self.category = category
        unseen = self.get_unseen_questions(category)

        # سؤال تکراری هرگز نمایش داده نمی‌شود؛ با تمام شدن بانک، بازی به خانه برمی‌گردد.
        if not unseen:
            self.manager.current = "home"
            print(f"تمام ۳۰۰ سؤال دستهٔ {category} استفاده شده‌اند.")
            return

        random.shuffle(unseen)
        self.questions = unseen[:min(10, len(unseen))]

        # هر سؤال زمانی ثبت می‌شود که واقعاً نمایش داده شود؛
        # سؤال‌هایی که بازیکن هنوز ندیده، بی‌دلیل از بانک حذف نمی‌شوند.

        self.index = 0
        self.correct = 0
        self.answer_locked = False

        player.combo = 0
        player.focus = 100
        player.missions += 1
        player.save()

        self.manager.current = "quiz"

    def start_timer(self):



        self.stop_timer()



        self.time_left = 15



        self.timer_event = Clock.schedule_interval(

            self.tick,

            1

        )



    def stop_timer(self):



        if self.timer_event:



            self.timer_event.cancel()

            self.timer_event = None



    def tick(self, dt):



        self.time_left -= 1



        screen = self.manager.get_screen(

            "quiz"

        )



        screen.update_timer()



        if self.time_left <= 0:



            self.stop_timer()



            if not self.answer_locked:



                self.answer_locked = True

                self.answer(-1)



    def next_question(self):



        self.answer_locked = False



        if self.index >= len(self.questions):



            self.stop_timer()



            self.manager.current = "result"



            return



        original = self.questions[

            self.index

        ]

        # فقط سؤال فعلی را ثبت کن، نه تمام سؤال‌های مسابقه را از ابتدا.
        self.mark_question_seen(self.category, original)

        q = dict(original)



        answers = list(q["a"])



        correct_text = answers[

            q["correct"]

        ]



        random.shuffle(answers)



        q["a"] = answers



        q["correct"] = answers.index(

            correct_text

        )



        self.current_question = q



        screen = self.manager.get_screen(

            "quiz"

        )



        screen.display_question()



        self.start_timer()



    def answer(self, selected):



        if self.answer_locked:

            return



        self.answer_locked = True



        self.stop_timer()



        q = self.current_question



        correct = (

            selected == q["correct"]

        )



        screen = self.manager.get_screen(

            "quiz"

        )



        screen.show_answer(

            selected,

            q["correct"]

        )



        if correct:



            self.correct += 1



            player.combo += 1



            if player.combo > player.best_combo:

                player.best_combo = player.combo



            multiplier = min(

                4,

                max(1, player.combo)

            )



            xp = 20 * multiplier

            coins = 10 * multiplier



            player.xp += xp

            player.coins += coins



            screen.feedback(

                True,

                xp,

                coins

            )



        else:



            player.combo = 0



            player.focus -= 20



            if player.focus < 0:

                player.focus = 0



            screen.feedback(

                False,

                0,

                0

            )



        player.save()



        self.index += 1



        Clock.schedule_once(

            lambda dt:

            self.next_question(),

            1.3

        )





game = Game()





# ============================================================

# صفحه Home

# ============================================================



class HomeScreen(Screen):
    """صفحهٔ اصلی با متن‌های واضح و بدون آیکن‌های پوشاننده."""
    def on_enter(self):
        self.clear_widgets()
        root = GameBackground(
            orientation="vertical",
            padding=[dp(12), dp(6), dp(12), dp(6)],
            spacing=dp(4)
        )
        content = BoxLayout(orientation="vertical", spacing=dp(5))
        header = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(88), spacing=0)
        header.add_widget(make_label("NEXORA", 27, CYAN))
        header.add_widget(make_label("A C A D E M Y", 10, PURPLE))
        header.add_widget(make_label("دانش، قدرت توست...", 13, WHITE))
        header.add_widget(make_label(f"سطح {player.level()}  |  {player.coins} سکه", 12, YELLOW))
        content.add_widget(header)
        content.add_widget(make_label("یک مسیر را انتخاب کن", 15, WHITE))

        # نام دسته‌ها مستقیماً روی خود دکمه قرار می‌گیرد؛ بنابراین زیر آیکن یا ویجت دیگری پنهان نمی‌شود.
        category_symbols = {
            "علوم": "[ + ]", "ریاضی": "[ Σ ]", "منطق": "[ ◇ ]",
            "انگلیسی": "[ A ]", "فناوری": "[ # ]", "جغرافیا": "[ O ]"
        }
        for category in CATEGORIES:
            name = category["name"]
            symbol = category_symbols.get(name, "[ * ]")
            card = Button(
                text=f"{symbol}     {rtl(name)}",
                size_hint_y=None, height=dp(51),
                font_name=FONT_PATH or "Roboto", font_size=sp(17),
                color=WHITE, halign="left", valign="middle",
                padding=(dp(14), 0),
                background_normal="", background_down="",
                background_color=tuple(category["color"][:3]) + (0.24,)
            )
            card.bind(size=lambda w, *_: setattr(w, "text_size", (w.width-dp(20), w.height)))
            with card.canvas.after:
                Color(*(category["color"][:3] + (1,)))
                outline = Line(rounded_rectangle=(card.x, card.y, card.width, card.height, dp(14)), width=1.25)
            def update_outline(w, *_args, line=outline):
                line.rounded_rectangle = (w.x, w.y, w.width, w.height, dp(14))
            card.bind(pos=update_outline, size=update_outline)
            card.bind(on_release=lambda _btn, c=name: game.start_quiz(c))
            content.add_widget(card)

        actions = BoxLayout(size_hint_y=None, height=dp(43), spacing=dp(7))
        battle = GameButton("⚔  مبارزه با باس", PURPLE, 43)
        battle.bind(on_release=lambda *_: setattr(self.manager, "current", "boss"))
        quiz = GameButton("▶  مسابقه معمولی", BLUE, 43)
        quiz.bind(on_release=lambda *_: setattr(self.manager, "current", "categories"))
        actions.add_widget(battle)
        actions.add_widget(quiz)
        content.add_widget(actions)

        quick = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(7))
        for title, screen, symbol in (("؟  راهنما", "help", "guide"), ("▤  آمار", "profile", "stats")):
            b = GameButton(title, CARD2, 40)
            b.bind(on_release=lambda _b, dest=screen: setattr(self.manager, "current", dest))
            quick.add_widget(b)
        content.add_widget(quick)

        exit_btn = GameButton("✕  خروج از بازی", RED, 38)
        exit_btn.size_hint_y = None
        exit_btn.height = dp(38)
        exit_btn.bind(on_release=lambda *_: App.get_running_app().stop())
        content.add_widget(exit_btn)
        footer = make_label("ساخته شده توسط ریحانه فرخی", 10, GRAY)
        footer.size_hint_y = None
        footer.height = dp(22)
        content.add_widget(footer)
        root.add_widget(content)
        self.add_widget(root)

    def play(self, *args):
        self.manager.current = "categories"
    def profile(self, *args):
        self.manager.current = "profile"
    def help(self, *args):
        self.manager.current = "help"


class CategoriesScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(16),

            spacing=dp(10)

        )



        root.add_widget(

            TopBar(

                "انتخاب دسته",

                "موضوع مسابقه را انتخاب کن"

            )

        )



        scroll = ScrollView()



        grid = GridLayout(

            cols=2,

            spacing=dp(12),

            padding=dp(4),

            size_hint_y=None

        )



        grid.bind(

            minimum_height=grid.setter(

                "height"

            )

        )



        for category in CATEGORIES:



            card = Button(

                text=(

                    f"[size=15sp]{rtl(category['title'])}[/size]\n"

                    f"[size=10sp]{category['english']}[/size]"

                ),

                markup=True,

                font_name=(

                    FONT_PATH

                    if FONT_PATH

                    else "Roboto"

                ),

                font_size=sp(15),

                color=WHITE,

                halign="center",

                valign="middle",

                background_normal="",

                background_color=(0, 0, 0, 0),

                size_hint_y=None,

                height=dp(145)

            )



            card.halign = "right"
            card.valign = "middle"
            card.padding = (dp(78), 0, dp(12), 0)

            with card.canvas.before:

                Color(

                    *category["color"]

                )

                rect = RoundedRectangle(

                    pos=card.pos,

                    size=card.size,

                    radius=[dp(22)]

                )

            # تصویر واقعی متناسب با دسته، داخل کارت انتخاب موضوع
            from kivy.core.image import Image as CoreImage
            try:
                icon_texture = CoreImage(category_image_path(category["name"])).texture
                with card.canvas.after:
                    Color(1, 1, 1, 1)
                    icon_rect = Rectangle(
                        texture=icon_texture,
                        pos=(card.x + dp(10), card.y + dp(42)),
                        size=(dp(48), dp(48)),
                    )
                def update_icon(instance, value, rect=icon_rect):
                    rect.pos = (instance.x + dp(10), instance.y + dp(42))
                card.bind(pos=update_icon, size=update_icon)
            except Exception as exc:
                print("بارگذاری تصویر دسته انجام نشد:", exc)



            def update_rect(

                instance,

                value,

                rect=rect

            ):



                rect.pos = instance.pos

                rect.size = instance.size



            card.bind(

                pos=update_rect,

                size=update_rect

            )



            card.bind(

                on_release=lambda x,

                c=category["name"]:

                self.start(c)

            )



            grid.add_widget(card)



        scroll.add_widget(grid)



        root.add_widget(scroll)



        back = GameButton(

            "بازگشت",

            CARD2,

            50

        )



        back.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(back)



        self.add_widget(root)



    def start(self, category):



        game.start_quiz(category)





# ============================================================

# صفحه Quiz

# ============================================================



class QuizScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        self.root_box = GameBackground(

            orientation="vertical",

            padding=dp(8),

            spacing=dp(5)

        )



        self.top_bar = TopBar(

            "",

            ""

        )
        self.top_bar.height = dp(56)



        self.root_box.add_widget(

            self.top_bar

        )



        # اطلاعات



        info = BoxLayout(

            orientation="horizontal",

            size_hint_y=None,

            height=dp(38),

            spacing=dp(8)

        )



        self.question_number = make_label(

            "",

            13,

            GRAY

        )



        self.combo_label = make_label(

            "",

            14,

            YELLOW

        )



        self.timer_label = make_label(

            "",

            18,

            CYAN

        )



        info.add_widget(

            self.question_number

        )



        info.add_widget(

            self.combo_label

        )



        info.add_widget(

            self.timer_label

        )



        self.root_box.add_widget(info)



        # پیشرفت



        self.progress = ProgressBar(

            max=10,

            value=0,

            size_hint_y=None,

            height=dp(7)

        )



        self.root_box.add_widget(

            self.progress

        )



        # کارت سوال



        self.question_card = Card(

            orientation="vertical",

            padding=dp(10),

            size_hint_y=None,

            height=dp(135),

            bg_color=CARD

        )



        self.question_icon = Image(
            source=category_image_path(game.category),
            size_hint=(None, None),
            size=(dp(44), dp(44)),
            allow_stretch=True,
            keep_ratio=True,
        )
        self.question_icon.size_hint_y = None
        self.question_icon.height = dp(44)
        self.question_card.add_widget(self.question_icon)

        self.question_label = make_label(
            "",
            19,
            WHITE
        )
        self.question_card.add_widget(self.question_label)



        self.root_box.add_widget(

            self.question_card

        )



        # جواب‌ها



        self.answers = GridLayout(

            cols=1,

            spacing=dp(9),

            size_hint_y=None

        )



        self.answers.bind(

            minimum_height=self.answers.setter(

                "height"

            )

        )



        self.root_box.add_widget(

            self.answers

        )



        # پیام



        self.message = make_label(

            "",

            15,

            GREEN

        )



        self.root_box.add_widget(

            self.message

        )



        # دکمه‌های بازگشت و خروج در صفحه سؤال‌ها
        nav = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40), spacing=dp(6))
        back_btn = decorate_button_icon(GameButton("بازگشت", PURPLE, 40), "back", dp(24))
        exit_btn = decorate_button_icon(GameButton("خروج از بازی", RED, 40), "exit", dp(24))
        back_btn.bind(on_release=lambda *_: (game.stop_timer(), setattr(self.manager, "current", "home")))
        exit_btn.bind(on_release=lambda *_: App.get_running_app().stop())
        nav.add_widget(back_btn)
        nav.add_widget(exit_btn)
        self.root_box.add_widget(nav)

        self.add_widget(

            self.root_box

        )



        Clock.schedule_once(

            lambda dt:

            game.next_question(),

            0.15

        )



    def display_question(self):



        q = game.current_question



        category = next(

            c for c in CATEGORIES

            if c["name"] == game.category

        )



        # تصویر متناسب با موضوع، بالای هر سؤال نمایش داده می‌شود.
        self.question_icon.source = category_image_path(game.category)
        self.question_icon.reload()

        self.top_bar.title_label.text = rtl(

            category["title"]

        )



        self.top_bar.subtitle_label.text = rtl(

            category["english"]

        )



        self.question_number.text = rtl(

            f"سؤال {game.index + 1} از "

            f"{len(game.questions)}"

        )



        self.combo_label.text = rtl(

            f"COMBO ×{max(1, min(4, player.combo))}"

        )



        self.question_label.text = rtl(

            q["q"]

        )



        self.message.text = ""



        self.progress.max = len(

            game.questions

        )



        self.progress.value = game.index



        self.answers.clear_widgets()



        for i, answer in enumerate(q["a"]):



            btn = GameButton(

                answer,

                CARD2,

                47

            )



            btn.bind(

                on_release=lambda x,

                index=i:

                self.select_answer(index)

            )



            self.answers.add_widget(btn)



        self.update_timer()



    def update_timer(self):



        self.timer_label.text = rtl(

            f"⏱ {game.time_left}"

        )



        if game.time_left <= 5:



            self.timer_label.color = RED



        else:



            self.timer_label.color = CYAN



    def select_answer(self, index):



        if game.answer_locked:

            return



        game.answer(index)



    def show_answer(

        self,

        selected,

        correct

    ):



        children = list(

            reversed(

                self.answers.children

            )

        )



        for i, btn in enumerate(children):



            btn.disabled = True



            if i == correct:



                btn.set_color(

                    GREEN

                )



            elif i == selected:



                btn.set_color(

                    RED

                )



    def feedback(

        self,

        correct,

        xp,

        coins

    ):



        if correct:



            self.message.color = GREEN



            self.message.text = rtl(

                f"✓ درست!    +{xp} XP    +{coins} سکه"

            )



        else:



            self.message.color = RED



            self.message.text = rtl(

                "✕ پاسخ اشتباه بود"

            )





# ============================================================

# نتیجه

# ============================================================



class ResultScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        game.stop_timer()



        root = GameBackground(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(15)

        )



        root.add_widget(

            TopBar(

                "نتیجه مسابقه",

                "RIREX • RESULTS"

            )

        )



        percentage = int(

            game.correct /

            max(

                1,

                len(game.questions)

            ) * 100

        )



        if percentage >= 80:



            title = "عالی بود! 🔥"

            color = GREEN



        elif percentage >= 60:



            title = "خوب بود! ⚡"

            color = YELLOW



        else:



            title = "دوباره تلاش کن"

            color = RED



        root.add_widget(

            make_label(

                title,

                34,

                color

            )

        )



        root.add_widget(

            make_label(

                game.category,

                16,

                GRAY

            )

        )



        result_card = Card(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(12),

            bg_color=CARD

        )



        result_card.add_widget(

            make_label(

                f"{game.correct} / "

                f"{len(game.questions)}",

                42,

                WHITE

            )

        )



        result_card.add_widget(

            make_label(

                f"دقت {percentage}%",

                18,

                color

            )

        )



        result_card.add_widget(

            make_label(

                f"بهترین کمبو: {player.best_combo}",

                16,

                YELLOW

            )

        )



        result_card.add_widget(

            make_label(

                f"{player.xp} XP     •     "

                f"{player.coins} سکه",

                15,

                GRAY

            )

        )



        root.add_widget(

            result_card

        )



        if percentage >= 70:



            boss = GameButton(

                "⚔ مبارزه با نگهبان",

                RED,

                64

            )



            boss.bind(

                on_release=self.boss

            )



            root.add_widget(boss)



        again = GameButton(

            "مسابقه دوباره",

            BLUE,

            58

        )



        again.bind(

            on_release=self.again

        )



        root.add_widget(again)



        city = GameButton(

            "بازگشت به خانه",

            CARD2,

            50

        )



        city.bind(

            on_release=self.home

        )



        root.add_widget(city)



        self.add_widget(root)



    def boss(self, *args):



        game.boss_hp = 3



        self.manager.current = "boss"



    def again(self, *args):



        game.start_quiz(

            game.category

        )



    def home(self, *args):



        self.manager.current = "home"





# ============================================================

# باس

# ============================================================



class BossScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(16)

        )



        root.add_widget(

            TopBar(

                "نگهبان هسته",

                "RIREX • BOSS BATTLE"

            )

        )



        root.add_widget(

            make_label(

                "نگهبان هسته",

                34,

                RED

            )

        )



        root.add_widget(

            make_label(

                "BOSS BATTLE",

                13,

                GRAY

            )

        )



        boss_card = Card(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(12),

            bg_color=CARD

        )



        boss_card.add_widget(

            make_label(

                f"❤️ {game.boss_hp} / 3",

                35,

                RED

            )

        )



        boss_card.add_widget(

            make_label(

                f"هسته {game.category}",

                22,

                WHITE

            )

        )



        boss_card.add_widget(

            make_label(

                "هر پاسخ درست یک ضربه به باس وارد می‌کند.",

                15,

                GRAY

            )

        )



        root.add_widget(

            boss_card

        )



        attack = GameButton(

            "⚔ حمله",

            RED,

            68

        )



        attack.bind(

            on_release=self.attack

        )



        root.add_widget(

            attack

        )



        back = GameButton(

            "فرار",

            CARD2,

            52

        )



        back.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(back)



        self.add_widget(root)



    def attack(self, *args):
        category = game.category
        unseen = game.get_unseen_questions(category)

        if not unseen:
            self.manager.current = "home"
            print(f"تمام ۳۰۰ سؤال دستهٔ {category} استفاده شده‌اند.")
            return

        question = random.choice(unseen)
        game.mark_question_seen(category, question)
        game.current_question = dict(question)
        self.manager.current = "boss_question"


# ============================================================


class BossQuestionScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        q = game.current_question



        root = GameBackground(

            orientation="vertical",

            padding=dp(15),

            spacing=dp(12)

        )



        root.add_widget(

            TopBar(

                "نبرد باس",

                "RIREX • ATTACK"

            )

        )



        root.add_widget(

            make_label(

                f"❤️ قدرت باس: {game.boss_hp}/3",

                24,

                RED

            )

        )



        card = Card(

            orientation="vertical",

            padding=dp(18),

            size_hint_y=None,

            height=dp(180),

            bg_color=CARD

        )



        category_info = next(
            (item for item in CATEGORIES if item["name"] == game.category),
            CATEGORIES[0]
        )
        topic_icon = Image(
            source=category_image_path(game.category),
            size_hint=(None, None),
            size=(dp(48), dp(48)),
            allow_stretch=True,
            keep_ratio=True,
        )
        topic_icon.size_hint_y = None
        topic_icon.height = dp(48)
        card.add_widget(topic_icon)

        card.add_widget(
            make_label(
                q["q"],
                19,
                WHITE
            )
        )



        root.add_widget(card)



        answers = GridLayout(

            cols=1,

            spacing=dp(9),

            size_hint_y=None

        )



        answers.bind(

            minimum_height=answers.setter(

                "height"

            )

        )



        for i, answer in enumerate(q["a"]):



            b = GameButton(

                answer,

                BLUE,

                58

            )



            b.bind(

                on_release=lambda x,

                index=i:

                self.answer(index)

            )



            answers.add_widget(b)



        root.add_widget(

            answers

        )



        nav = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(44), spacing=dp(8))
        back_btn = decorate_button_icon(GameButton("بازگشت", PURPLE, 40), "back", dp(24))
        exit_btn = decorate_button_icon(GameButton("خروج از بازی", RED, 40), "exit", dp(24))
        back_btn.bind(on_release=lambda *_: setattr(self.manager, "current", "home"))
        exit_btn.bind(on_release=lambda *_: App.get_running_app().stop())
        nav.add_widget(back_btn)
        nav.add_widget(exit_btn)
        root.add_widget(nav)

        self.add_widget(root)



    def answer(self, index):



        q = game.current_question



        if index == q["correct"]:



            game.boss_hp -= 1



            player.xp += 50

            player.coins += 25



            if game.boss_hp <= 0:



                player.bosses += 1



                player.xp += 100

                player.coins += 100



                player.save()



                self.manager.current = "victory"



            else:



                player.save()



                self.manager.current = "boss"



        else:



            player.focus -= 25



            if player.focus < 0:

                player.focus = 0



            player.save()



            self.manager.current = "defeat"





# ============================================================

# پیروزی

# ============================================================



class VictoryScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(18)

        )



        root.add_widget(

            TopBar(

                "پیروزی",

                "RIREX • VICTORY"

            )

        )



        root.add_widget(

            make_label(

                "VICTORY",

                18,

                YELLOW

            )

        )



        root.add_widget(

            make_label(

                "پیروزی! 🏆",

                40,

                YELLOW

            )

        )



        card = Card(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(12),

            bg_color=CARD

        )



        card.add_widget(

            make_label(

                "نگهبان هسته شکست خورد!",

                22,

                WHITE

            )

        )



        card.add_widget(

            make_label(

                "+۱۵۰ XP\n+۱۲۵ سکه",

                20,

                GREEN

            )

        )



        card.add_widget(

            make_label(

                "یک هسته دانش بازیابی شد.",

                16,

                GRAY

            )

        )



        root.add_widget(card)



        btn = GameButton(

            "بازگشت به خانه",

            BLUE,

            62

        )



        btn.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(btn)



        self.add_widget(root)





# ============================================================

# شکست

# ============================================================



class DefeatScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(18)

        )



        root.add_widget(

            TopBar(

                "شکست",

                "RIREX • DEFEAT"

            )

        )



        root.add_widget(

            make_label(

                "DEFEAT",

                17,

                RED

            )

        )



        root.add_widget(

            make_label(

                "این بار نشد!",

                36,

                RED

            )

        )



        root.add_widget(

            make_label(

                "نگهبان هنوز شکست نخورده.\n"

                "دوباره امتحان کن.",

                19,

                WHITE

            )

        )



        retry = GameButton(

            "⚔ دوباره تلاش کن",

            BLUE,

            65

        )



        retry.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "boss"

            )

        )



        root.add_widget(retry)



        home = GameButton(

            "بازگشت",

            CARD2,

            52

        )



        home.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(home)



        self.add_widget(root)





# ============================================================

# پروفایل

# ============================================================



class ProfileScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(18),

            spacing=dp(12)

        )



        root.add_widget(

            TopBar(

                "پروفایل بازیکن",

                "RIREX • PLAYER"

            )

        )



        root.add_widget(

            make_label(

                "پروفایل بازیکن",

                29,

                CYAN

            )

        )



        card = Card(

            orientation="vertical",

            padding=dp(20),

            spacing=dp(9),

            bg_color=CARD

        )



        card.add_widget(

            make_label(

                f"LEVEL {player.level()}",

                30,

                YELLOW

            )

        )



        card.add_widget(

            make_label(

                player.rank(),

                18,

                WHITE

            )

        )



        card.add_widget(

            make_label(

                f"XP: {player.xp}",

                16,

                GRAY

            )

        )



        card.add_widget(

            make_label(

                f"سکه: {player.coins}",

                16,

                YELLOW

            )

        )



        card.add_widget(

            make_label(

                f"بهترین کمبو: {player.best_combo}",

                16,

                PURPLE

            )

        )



        card.add_widget(

            make_label(

                f"مسابقات: {player.missions}",

                16,

                WHITE

            )

        )



        card.add_widget(

            make_label(

                f"باس‌های شکست‌خورده: {player.bosses}",

                16,

                RED

            )

        )



        card.add_widget(

            make_label(

                f"تمرکز: {player.focus}%",

                16,

                GREEN

            )

        )



        root.add_widget(card)



        back = GameButton(

            "بازگشت",

            CARD2,

            55

        )



        back.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(back)



        self.add_widget(root)





# ============================================================

# راهنما

# ============================================================



class HelpScreen(Screen):



    def on_enter(self):



        self.clear_widgets()



        root = GameBackground(

            orientation="vertical",

            padding=dp(18),

            spacing=dp(12)

        )



        root.add_widget(

            TopBar(

                "راهنما",

                "RIREX • GUIDE"

            )

        )



        root.add_widget(

            make_label(

                "راهنمای NEXORA",

                29,

                YELLOW

            )

        )



        scroll = ScrollView()



        text = (

            "🎮 هدف بازی\n\n"

            "دانش خودت را در دسته‌های مختلف "

            "امتحان کن و سطح خودت را بالا ببر.\n\n"



            "⚡ امتیاز\n\n"

            "هر پاسخ درست XP و سکه می‌دهد.\n\n"



            "🔥 COMBO\n\n"

            "چند پاسخ درست پشت سر هم باعث "

            "افزایش ضریب پاداش می‌شود.\n\n"



            "⏱ زمان\n\n"

            "برای هر سؤال ۱۵ ثانیه زمان داری.\n\n"



            "⚔ BOSS\n\n"

            "اگر عملکرد خوبی داشته باشی، "

            "می‌توانی با نگهبان هسته مبارزه کنی.\n\n"



            "🏆 هدف نهایی\n\n"

            "سطح خودت را بالا ببر و تبدیل به "

            "افسانه نکسورا شو."

        )



        scroll.add_widget(

            make_label(

                text,

                17,

                WHITE

            )

        )



        root.add_widget(scroll)



        back = GameButton(

            "بازگشت",

            CARD2,

            55

        )



        back.bind(

            on_release=lambda x:

            setattr(

                self.manager,

                "current",

                "home"

            )

        )



        root.add_widget(back)



        self.add_widget(root)





# ============================================================

# App

# ============================================================



def update_mouse_cursor(window, mouse_pos):
    """وقتی ماوس روی دکمه‌های قابل کلیک است، نشانگر به شکل دست درمی‌آید."""
    app = App.get_running_app()
    root = getattr(app, "root", None) if app else None
    if root is None:
        return
    try:
        widgets = list(root.walk())
        over_button = any(
            isinstance(widget, Button) and widget.opacity > 0 and widget.disabled is False
            and widget.collide_point(*mouse_pos)
            for widget in widgets
        )
        Window.set_system_cursor("hand" if over_button else "arrow")
    except Exception:
        pass


class NEXORAApp(App):



    def build(self):



        self.title = "RIREX - NEXORA Academy"
        if platform != "android":
            Window.fullscreen = False
            Window.resizable = False
            Window.size = (400, 700)
            Window.minimum_width = Window.maximum_width = 400
            Window.minimum_height = Window.maximum_height = 700
            Clock.schedule_once(lambda _dt: self._lock_window_size(), 0.1)

        manager = ScreenManager(

            transition=FadeTransition(

                duration=0.18

            )

        )
        # نگه‌داشتن ارجاع به ScreenManager چون ریشهٔ برنامه شامل کادر پایینی نیز هست.
        self.screen_manager = manager



        manager.add_widget(

            HomeScreen(

                name="home"

            )

        )



        manager.add_widget(

            CategoriesScreen(

                name="categories"

            )

        )



        manager.add_widget(

            QuizScreen(

                name="quiz"

            )

        )



        manager.add_widget(

            ResultScreen(

                name="result"

            )

        )



        manager.add_widget(

            BossScreen(

                name="boss"

            )

        )



        manager.add_widget(

            BossQuestionScreen(

                name="boss_question"

            )

        )



        manager.add_widget(

            VictoryScreen(

                name="victory"

            )

        )



        manager.add_widget(

            DefeatScreen(

                name="defeat"

            )

        )



        manager.add_widget(

            ProfileScreen(

                name="profile"

            )

        )



        manager.add_widget(

            HelpScreen(

                name="help"

            )

        )



        # پوستهٔ اصلی: صفحه‌ها + کادر پایینی چشمک‌زن برای امضای سازنده
        app_root = BoxLayout(orientation="vertical", spacing=dp(4), padding=(dp(6), dp(4), dp(6), dp(4)))
        app_root.add_widget(manager)

        footer = AnchorLayout(size_hint_y=None, height=dp(34), anchor_x="center", anchor_y="center")
        footer_label = Label(
            text=rtl("✦ ساخته شده توسط ریحانه فرخی ✦"),
            font_size=sp(12),
            color=(1, 0.72, 1, 1),
            halign="center",
            valign="middle",
            size_hint=(1, 1),
        )
        if FONT_PATH:
            footer_label.font_name = FONT_PATH
        with footer_label.canvas.before:
            Color(0.18, 0.025, 0.32, 0.95)
            footer_bg = RoundedRectangle(pos=footer_label.pos, size=footer_label.size, radius=[dp(14)])
            Color(0.78, 0.18, 1, 0.95)
            footer_border = Line(rounded_rectangle=(footer_label.x, footer_label.y, footer_label.width, footer_label.height, dp(14)), width=1.2)
        def update_footer_graphics(instance, value):
            footer_bg.pos = instance.pos
            footer_bg.size = instance.size
            footer_border.rounded_rectangle = (instance.x, instance.y, instance.width, instance.height, dp(14))
        footer_label.bind(pos=update_footer_graphics, size=update_footer_graphics)
        footer.add_widget(footer_label)
        app_root.add_widget(footer)

        blink = Animation(opacity=0.35, duration=0.65) + Animation(opacity=1, duration=0.65)
        blink.repeat = True
        blink.start(footer_label)

        Window.bind(mouse_pos=update_mouse_cursor)
        return app_root



    def _lock_window_size(self, *args):
        if platform != "android":
            Window.resizable = False
            Window.minimum_width = Window.maximum_width = 400
            Window.minimum_height = Window.maximum_height = 700
            Window.size = (400, 700)

    def on_stop(self):



        game.stop_timer()

        player.save()





# ============================================================

# اجرای برنامه

# ============================================================



if __name__ == "__main__":



    NEXORAApp().run()
