پروژه آماده ساخت APK بازی NEXORA ACADEMY

محتویات:
- main.py: کد اصلاح‌شده بازی
- buildozer.spec: تنظیمات ساخت APK اندروید
- nexora_assets/: آیکن‌های مورد نیاز بازی
- Vazirmatn-Regular.ttf: فونت همراه برنامه

برای ساخت APK، پوشه را در محیط Linux یا Google Colab بسازید. Buildozer روی ویندوز خام اجرا نمی‌شود و به Linux/WSL یا محیطی مثل Colab نیاز دارد.

در Colab ابتدا فایل ZIP را آپلود و استخراج کنید، سپس در پوشه پروژه این دستورات را اجرا کنید:

sudo apt-get update
sudo apt-get install -y git zip unzip openjdk-17-jdk python3-pip python3-venv autoconf libtool pkg-config zlib1g-dev libncurses-dev cmake libffi-dev libssl-dev automake
python3 -m pip install --upgrade pip setuptools wheel
python3 -m pip install --upgrade buildozer cython==0.29.34
buildozer -v android debug

در پایان فایل APK در پوشه bin ساخته می‌شود.

توجه: آیکن‌های داخل این بسته جایگزین‌های ساده‌اند؛ اگر پوشه nexora_assets اصلی را دارید، می‌توانید PNGهای اصلی را با همین نام‌ها جایگزین کنید.
