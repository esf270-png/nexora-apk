[app]
title = NEXORA ACADEMY
package.name = nexoraacademy
package.domain = org.nexora
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,json,ttf
version = 1.0.0
requirements = python3,kivy,arabic-reshaper,python-bidi
orientation = portrait
fullscreen = 1
icon.filename = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/icon.png

# Android
android.api = 35
android.minapi = 23
android.ndk = 27c
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = True

# Build settings
[buildozer]
log_level = 2
warn_on_root = 1
